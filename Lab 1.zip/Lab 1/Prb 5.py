val = input("Enter your value: ")
print(val)