age = 45
salary = 1456.8
name = "John"

print(age)
print(salary)
print(name)