name = "geeksforgeeks"
print(name) 