a = 9
b = 4
add = a + b
sub = a - b
mul = a * b
mod = a % b
p = a ** b

print(add)
print(sub)
print(mul)
print(mod)
print(p)
