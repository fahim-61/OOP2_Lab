
a = [1,3,5,7,4]
print(len(a))
print(type(a))
print(a[-2], ",", a[2])

a[-3]=50
print(a)

print(a[2:4], ",",a[:-3])

a.append(100)
print(a)
a.insert(2,200)
print(a)

a.pop(-1)
a.pop(1)
print(a)

n=[2,4,6]
a=a+n
print(a)

b=a.copy()
b.sort()
print(b)



a=[1,3,5,7,4]
print(sum(num for num in a if num % 2 != 0))

sum=0
for i in range(len(a)):
    if i%2==1:
        sum=sum+a[i]
print(sum)

odd=0
even=0
for i in a:
    if i%2==0:
        even+=1
    else:
        odd+=1
print("Even: ",even,",","Odd:",odd)



a = (1,3,5,7,4)
print(len(a))
print(type(a))
print(a[-2], ",", a[2])

a=list(a)
a[-3]=50
a=tuple(a)
print(a)

print(a[2:4], ",",a[:-3])

a=list(a)
a.append(100)
print(a)
a.insert(2,200)
print(a)

a.pop(-1)
a.pop(1)
print(a)

n=[2,4,6]
a=a+n
print(a)

b=a.copy()
b.sort()
b=tuple(b)
print(b)



