list= [1,2,3,4]
for i in list:
    if i%2==0:
        print(i, "a even number")