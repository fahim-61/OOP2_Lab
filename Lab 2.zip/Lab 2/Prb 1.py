mul = 5
count = 1

while count <= 10:
    res = mul * count
    if res == 25:
        count += 1
        continue
    if res == 45:
        break
    print(mul, "*", count, "=", res)
    count += 1
