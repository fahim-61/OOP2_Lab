#Global Scope
a = 5; b = 6

#Local Scop
def scope_test():
    print("Access the value of Global a =", a)
    b = 10
    c = 15
    print("Value of Local b = ", b)
    print("Value of Local c = ", c)

scope_test()
print("Value of Global b = ",b)
print("value of local c = ",c)