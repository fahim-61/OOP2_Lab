def oddEven(num):
    if num % 2 == 0:
        return 0
    else:
        return 1

num = int(input("Number: "))
res = oddEven(num)
print(res)
