emp ={"name": "A",
      "age": 40,
      "type": {"developer": ["IOS", "android"]},
      "Permanent":  True,
      "salary": 30000.3,
      100: (1, 2, 3),
      4.5: {5, 6, True, 7, 1},
      True: 1
      }

print(type(emp))
print(len(emp))

print(emp["type"])
print(emp["type"]["developer"])
print(emp["type"]["developer"][1])
print(emp[4.5])
print(emp["age"])

emp["Permanent"]= False
print(emp["Permanent"])

emp["Gender"] = "male"
print(emp)

emp.pop("age")
print(emp)

for x in emp.keys():
  print(x)
for x in emp.items():
  print(x)
for x in emp.values():
  print(x)



child1 = {
  "name" : "Emil",
  "year" : 2004
}
child2 = {
  "name" : "Tobias",
  "year" : 2007
}
child3 = {
  "name" : "Linus",
  "year" : 2011
}
myfamily = {
  "child1" : child1,
  "child2" : child2,
  "child3" : child3
}
myfamily["child1"]["cgpa"]=3.72
print("\n\n")
print(myfamily)




