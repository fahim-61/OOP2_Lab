a= {1, 3, 5, 8, 3, 7}
b= {0, False, 1, 5}

print(len(a))
print(type(a))

a.add(10)
print(a)

a.remove(8)
print(a)

print(a&b)
print(a|b)
print(a-b)

for i in a:
    if i==5:
        break
    print(i)

b = {2,3,4}
a.update(b)
print(a)

if 3 in a:
    print("3 is Present")

print(a.issubset(b))
print(a.issuperset(b))



